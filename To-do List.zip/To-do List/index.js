let test_number = document.getElementById('text__change');
let body = document.getElementsByTagName('body')

let initialValue = test_number.innerHTML;
let numColor;
let bgColor;

let container = document.getElementById('container');
setInterval(function(){
    initialValue = initialValue > 0 ? initialValue - 1 : 0;
    test_number.innerHTML = initialValue;
    test_number.style.fontSize = initialValue * 100 + 'px';
    numColor = initialValue % 2 === 0 ? 'white' : 'blue';
    bgColor = initialValue % 2 === 0 ? 'black' : 'white';

    test_number.style.color = numColor;
    container.style.backgroundColor = bgColor;


}, 1000)